module.exports = {
    init: function () {
        console.log('init');
    }
}
