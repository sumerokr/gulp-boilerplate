module.exports = function (num) {
    return 4 * num;
}
