(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var tvilApp = require('./tvilApp');
var mainMenu = require('./mainMenu');
var mp = require('./multiply');
var hl = require('./helloer');

console.log(mp(4));
console.log(hl('Alex'));

},{"./helloer":2,"./mainMenu":3,"./multiply":4,"./tvilApp":5}],2:[function(require,module,exports){
var prefix = 'Hello, ';

module.exports = function (name) {
    return prefix + name;
}

},{}],3:[function(require,module,exports){
var tvilApp = require('./tvilApp');

tvilApp.mainMenu = {
    init: function () {
        console.log('init');
    },
    countItems: function () {
        return 5;
    }
};

},{"./tvilApp":5}],4:[function(require,module,exports){
var mult = 3;

module.exports = function (num) {
    return num * mult;
}

},{}],5:[function(require,module,exports){
module.exports = window.tvilApp = {};
},{}]},{},[1]);
